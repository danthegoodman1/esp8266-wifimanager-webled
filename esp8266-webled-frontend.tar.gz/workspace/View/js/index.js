window.addEvent('domready', function() {( function(globe) {
			var prefix = ["", "Webkit", "ms", "Moz", "O"];
			var setRotate = function(node, deg) {
				Array.each(prefix, function(item) {
					var s = item ? item + "Transform" : "transform";
					node.setStyle(s, "rotate(" + deg + "deg)");
				});
			};
			var ColorPicker = globe.ColorPicker = new Class({
				initialize : function(container, size, smoothness) {
					var hPanel = new Element("div", {
						id : "hPanel",
						styles : {
							width : size,
							height : size
						}
					});
					var hColorPanel = new Element("ul", {
						styles : {
							width : size,
							height : size
						}
					});
					this.size = size;
					var colorSldH = this.size * 3 / 2, s = smoothness || 6;
					var bw = Math.ceil(Math.sin(s * Math.PI / 360) * colorSldH) + 4;
					for (var i = 0; i < 360 / s; i++) {
						var h = i * s, c = new Color([h, 100, 100], "hsb");
						var li = new Element('li');
						li.setStyles({
							borderTopWidth : colorSldH,
							borderTopColor : c,
							borderTopStyle : "solid",
							borderLeft : bw + "px solid transparent",
							borderRight : bw + "px solid transparent",
							borderBottom : 0,
							marginLeft : -bw,
							marginTop : -colorSldH
						});

						Array.each(prefix, function(item) {
							var s2 = item ? item + "TransformOrigin" : "transformOrigin";
							li.setStyle(s2, "center bottom");
						});

						setRotate(li, h);
						li.inject(hColorPanel);
					}
					var hColorBar = this.hColorBar = new Element("div", {
						id : "hColorBar",
						styles : {
							height : size * 3 / 2,
							marginTop : -size * 3 / 2
						}
					});
					Array.each(prefix, function(item) {
						var s2 = item ? item + "TransformOrigin" : "transformOrigin";
						hColorBar.setStyle(s2, "center bottom");
					});
					var hCenter = new Element("div", {
						id : "hCenter",
						styles : {
							width : size / 5,
							marginLeft : -size / 10 - 3,
							height : size / 5,
							marginTop : -size / 10 - 3
						}
					});

					var hPanelCover = this.hPanelCover = new Element("div", {
						id : "hPanelCover",
						styles : {
							width : size,
							height : size,
							cursor : "crosshair"
						}
					});

					hColorPanel.inject(hPanel);
					hColorBar.inject(hPanel);
					hCenter.inject(hPanel);
					hPanelCover.inject(hPanel);
					var sbPanel = this.sbPanel = new Element("div", {
						id : "sbPanel",
						styles : {
							width : size,
							height : size
						}
					});

					var sbPanelWhite = new Element("div", {
						id : "sbPanelWhite",
						styles : {
							width : size,
							height : size
						}
					});

					var sbPanelBlack = new Element("div", {
						id : "sbPanelBlack",
						styles : {
							width : size,
							height : size
						}
					});

					Array.each(prefix, function(item) {
						var gradientPrefix = item ? "-" + item.toLowerCase() + "-linear-gradient(" : "linear-gradient(";
						var gradientStr = function(start, end, type) {
							var t = {
								h : "left",
								v : "top"
							};
							return gradientPrefix + t[type] + ", " + start + " 0%," + end + " 100%)";
						};

						sbPanelWhite.setStyle("background", gradientStr("rgba(255,255,255,1)", "rgba(255,255,255,0)", "h"));
						sbPanelBlack.setStyle("background", gradientStr("rgba(0,0,0,0)", "rgba(0,0,0,1)", "v"));
					});

					var sbPanelRing = this.sbPanelRing = new Element("div", {
						id : "sbPanelRing",
						html : "<p></p>"
					});

					var sbPanelCover = this.sbPanelCover = new Element("div", {
						id : "sbPanelCover",
						styles : {
							width : size,
							height : size,
							cursor : "crosshair"
						}
					});

					sbPanelWhite.inject(sbPanel);
					sbPanelBlack.inject(sbPanel);
					sbPanelRing.inject(sbPanel);
					sbPanelCover.inject(sbPanel);

					if (typeOf(container) == "string") {
						hPanel.inject($(container));
						sbPanel.inject($(container));
					} else {
						throw new Error("Container not found.");
					}

					var isHMove, isSBMove, self = this;
					hPanelCover.addEvent("mousedown", function(event) {
						isHMove = true;
						var x = event.client.x, y = event.client.y;
						self.setH(x, y);
					});
					sbPanelCover.addEvent("mousedown", function(event) {
						isSBMove = true;
						var x = event.client.x, y = event.client.y;
						self.setSB(x, y);
					});
					document.addEvents({
						"mousemove" : function(event) {
							var x = event.client.x, y = event.client.y;
							isHMove && self.setH(x, y);
							isSBMove && self.setSB(x, y);
						},
						"mouseup" : function() {
							isHMove = false;
							isSBMove = false;
							// can check mouse up using this
							// going to use on mouse up so I don't send hundreds of requests changing colors
							console.log("mouse up");
							// console.log(document.getElementById("redC").innerHTML);
							let dataOBJ = {
								redColor: document.getElementById("redC").innerHTML,
								greenColor: document.getElementById("greenC").innerHTML,
								blueColor: document.getElementById("blueC").innerHTML
							}
							console.log(JSON.stringify(dataOBJ));
							
							var xhr = new XMLHttpRequest();
							var url = "http://104.236.103.190/setcolors/";
							xhr.open("POST", url, true);
							xhr.setRequestHeader("Content-Type", "application/json;charset=UTF-8");
							xhr.onreadystatechange = function () {
							    if (xhr.readyState === 4 && xhr.status === 200) {
							        alert("sent colors!");
							    }
							};

							// WOW I JUST NEEDED TO STRINGIFY THE DATA TO MAKE THE ERRORS STOP LOL
							xhr.send(JSON.stringify(dataOBJ));
							
							// $.ajax({
							// 	  url: "104.236.103.190/setcolors",
							// 	  type: 'POST',
							// 	  contentType: 'application/json',
							// 	  data: JSON.stringify(dataOBJ)
							// }).done(function(data){
							// 	  console.log("Response of: " + data);
							// })
						}
					});
				},
				setH : function(x, y) {
					var dim = this.hPanelCover.getCoordinates();
					var dx = x - dim.left - dim.width / 2, dy = y - dim.top - dim.height / 2;

					var rad = (180 + Math.atan2(-dy, -dx) * 180 / Math.PI + 360) % 360;

					this.hsb[0] = Math.round(rad + 90);

					setRotate(this.hColorBar, this.hsb[0]);
					this.sbPanel.setStyle("backgroundColor", new Color([this.hsb[0], 100, 100], "hsb"));
					this.colorChange && this.colorChange(this.hsb);
				},
				setSB : function(x, y) {
					var dim = this.sbPanelCover.getCoordinates();
					var dx = Math.min(Math.max(x - dim.left, 0), dim.width), dy = Math.min(Math.max(y - dim.top, 0), dim.height);
					this.sbPanelRing.setStyles({
						left : dx,
						top : dy
					});
					this.hsb[1] = Math.round(dx / this.size * 100);
					this.hsb[2] = Math.round((1 - dy / this.size) * 100);
					this.colorChange && this.colorChange(this.hsb);
				},
				updateColor : function(value) {
					var myColor = new Color(value);
					this.hsb = myColor.hsb;
					var self = this;

					setRotate(this.hColorBar, this.hsb[0]);
					this.sbPanel.setStyle("backgroundColor", new Color([self.hsb[0], 100, 100], "hsb"));
					var l = Math.round(this.hsb[1] / 100 * this.size), t = Math.round((1 - this.hsb[2] / 100) * this.size);
					this.sbPanelRing.setStyles({
						left : l,
						top : t
					});
					this.colorChange && this.colorChange(this.hsb);
				}
			});
		}(window));

	//Usage: new ColorPicker(container, size, smoothness)
	var colorPicker = new ColorPicker("colorPicker", 200, 3);
	colorPicker.colorChange = function(color) {
		// on new color change
		var c = new Color(color, 'hsb');
		$('colorInfo').setStyle('color', c);
		$$('#colorInfo span.hex').set('text', c.rgbToHex());
		$$('#colorInfo span.r').set('text', c[0]);
		$$('#colorInfo span.g').set('text', c[1]);
		$$('#colorInfo span.b').set('text', c[2]);
	};
	colorPicker.updateColor("#3ea");
});