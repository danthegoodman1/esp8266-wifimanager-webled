var express = require('express');
var path = require('path');

let api = "104.236.103.190";

var app = express();

app.use(express.static(path.join(__dirname, "/View")));

app.get("/", (req, res) => {
   console.log("request") ;
});

app.listen(8080);